package com.example.splash;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import androidx.appcompat.app.AppCompatActivity;

public class NameActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_name); // Layout da tela com seu nome

        // Atraso de 2 segundos (2000 ms) antes de ir para a MainActivity
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                // Após o nome ser exibido, navega para a MainActivity
                Intent intent = new Intent(NameActivity.this, MainActivity.class);
                startActivity(intent);
                finish(); // Finaliza a NameActivity para que o usuário não possa voltar a ela
            }
        }, 2000); // 2000 milissegundos = 2 segundos
    }
}
