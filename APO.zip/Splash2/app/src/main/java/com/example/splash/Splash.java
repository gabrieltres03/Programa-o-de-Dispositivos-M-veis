package com.example.splash;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Timer;
import java.util.TimerTask;

public class Splash extends AppCompatActivity {

    private final Timer timer = new Timer();
    TimerTask timerTask;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        // Definir um atraso de 3 segundos para navegar para a NameActivity
        timerTask = new TimerTask() {
            @Override
            public void run() {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        // Após a splash, navega para a NameActivity
                        Intent intent = new Intent(Splash.this, NameActivity.class);
                        startActivity(intent);
                        finish(); // Finaliza a SplashActivity para que o usuário não possa voltar a ela
                    }
                });
            }
        };

        // Atraso de 3 segundos (3000ms) para exibir a tela inicial
        timer.schedule(timerTask, 3000);
    }
}
