package com.example.splash;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private MyAdapter adapter;
    private List<Item> itemList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inicializa o RecyclerView
        recyclerView = findViewById(R.id.recyclerView);

        // Define o layout como um layout linear (lista vertical)
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Cria a lista de itens
        itemList = new ArrayList<>();
        populateItemList();

        // Configura o adaptador
        adapter = new MyAdapter(itemList);
        recyclerView.setAdapter(adapter);
    }

    // Método para preencher a lista de itens com dados de exemplo
    private void populateItemList() {
        itemList.add(new Item("Toledo", "23°C"));
        itemList.add(new Item("Cascavel", "26°C"));
        itemList.add(new Item("Curitiba", "18°C"));
        itemList.add(new Item("São Paulo", "32°C"));
        itemList.add(new Item("Rio Grande do Sul", "20°C"));
        // Adicione mais itens conforme necessário
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Infla o menu; isso adiciona itens à barra de ação se estiver presente.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Lida com os cliques no menu da AppBar
        int id = item.getItemId();
        if (id == R.id.action_profile) {
            // Abre a Activity de Informações Pessoais
            Intent intent = new Intent(this, ProfileActivity.class);
            startActivity(intent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
